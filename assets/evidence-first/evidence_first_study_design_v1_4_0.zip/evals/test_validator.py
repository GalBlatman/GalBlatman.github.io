#!/usr/bin/env python3
"""Negative tests for validate_package.py: each breaks one thing in a temporary
copy of the package and expects the named check to fail. Standard library only.
Does NOT run or grade model behavior."""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True  # a __pycache__ folder would itself fail the package check
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_package import validate  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SKILL = 'skills/evidence-first-study-design'


def _json(path: Path, change) -> None:
    data = json.loads(path.read_text(encoding='utf-8'))
    change(data)
    path.write_text(json.dumps(data, indent=2), encoding='utf-8')


def version_mismatch(root: Path) -> None:
    _json(root / 'plugin.json', lambda d: d.update(version='9.9.9'))


def em_dash(root: Path) -> None:
    p = root / SKILL / 'references/design-and-confirm.md'
    p.write_text(p.read_text(encoding='utf-8') + '\nA line with an em dash \u2014 here.\n', encoding='utf-8')


def broken_route(root: Path) -> None:
    (root / SKILL / 'references/worked-examples.md').rename(root / SKILL / 'references/examples.md')


def case_count(root: Path) -> None:
    p = root / 'evals/cases.jsonl'
    p.write_text('\n'.join(p.read_text(encoding='utf-8').splitlines()[:-1]) + '\n', encoding='utf-8')


def unscoped_description(root: Path) -> None:
    p = root / SKILL / 'SKILL.md'
    p.write_text(p.read_text(encoding='utf-8').replace('Do not invoke', 'Avoid', 1), encoding='utf-8')


def fabricated_run(root: Path) -> None:
    _json(root / 'evals/TEST_STATUS.json', lambda d: d.update(behavioral_evaluation='PASS'))


def long_unindexed_reference(root: Path) -> None:
    p = root / SKILL / 'references/worked-examples.md'
    p.write_text(p.read_text(encoding='utf-8') + '\nfiller line\n' * 120, encoding='utf-8')


TESTS = [
    (version_mismatch, 'metadata synchronized'),
    (em_dash, 'no em dash'),
    (broken_route, 'internal link'),
    (case_count, 'case count matches status'),
    (unscoped_description, 'description scoped'),
    (fabricated_run, 'behavioral execution not fabricated'),
    (long_unindexed_reference, 'reference short or indexed worked-examples.md'),
]


def main() -> int:
    baseline = validate(ROOT)
    results = [{'test': 'unmodified package passes', 'ok': baseline['status'] == 'PASS'}]
    for mutate, expected in TESTS:
        with tempfile.TemporaryDirectory() as tmp:
            copy = Path(tmp) / 'pkg'
            shutil.copytree(ROOT, copy, ignore=shutil.ignore_patterns('__pycache__'))
            mutate(copy)
            try:
                out = validate(copy)
                failed = [c['check'] for c in out.get('checks', []) if c['status'] == 'FAIL']
                ok = out['status'] == 'FAIL' and any(name.startswith(expected) for name in failed)
            except (OSError, ValueError, KeyError) as exc:
                failed, ok = [repr(exc)], False
        results.append({'test': mutate.__name__, 'expects_failure_of': expected, 'ok': ok, 'failed_checks': failed})
    negative = results[1:]
    summary = {'status': 'PASS' if all(r['ok'] for r in results) else 'FAIL',
               'negative_tests_run': len(negative), 'negative_tests_passed': sum(r['ok'] for r in negative),
               'results': results}
    print(json.dumps(summary, indent=2))
    return 0 if summary['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
