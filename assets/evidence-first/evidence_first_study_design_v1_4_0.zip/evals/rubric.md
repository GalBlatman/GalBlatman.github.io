# Behavioral evaluation rubric

These cases are synthetic regressions derived from recurring workflow failures, not project data. They test behavior rather than one required scientific conclusion. Do not load this rubric into a normal research response. Keep expected behaviors hidden from the evaluated model.

## Run actual sessions

Use a fresh target-host conversation for each single-turn case. Install this release in that host and send only the case's user turn. Test implicit activation without mentioning the skill; optionally repeat selected cases with explicit invocation. For multi-turn cases, send turns sequentially in one fresh conversation, retaining the model's actual responses without correction between turns. Do not replace those responses with idealized text.

Capture model and host, plugin version, date, skill activation and references loaded where visible, exact messages, final outputs, tool actions, unexpected writes, and any intervention. Host traces absent means activation is NOT_OBSERVED, not a pass. Preserve negative cases where no skill should load. Use identical inputs to compare releases, and retain unsuccessful trials. Repeat enough cases to expose variation before asserting an improvement; do not infer robustness from one successful run.

No automatic live-model runner is bundled. The release environment had no Codex executable or fresh-chat evaluation tool. The included Python validator checks packaging and case structure only. An author reread is not an independent model test. Mark behavioral cases NOT_RUN until an actual host session exists.

## Grade the substantive behavior

For each case, grade each must_observe as MET, PARTIAL, NOT_MET or NOT_OBSERVED and each must_not_observe as ABSENT, PRESENT or NOT_OBSERVED, with a response or trace locator. A reasonable alternative scientific judgment can pass if evidence and the research question are preserved. Do not score by keyword presence alone.

Across cases inspect six dimensions:

1. Evidence fidelity: source-grounding, denominator and boundary correctness, uncertainty placed on the claim it affects.
2. Theoretical usefulness: quantities connected to constructs and the accumulated process, not just labels or lists.
3. Scope continuity: original question preserved through contrary findings and repairs without protecting a favored answer.
4. Proportional process: no invented gates, obligatory amendments, unnecessary artifacts or unrequested research expansion.
5. Execution integrity: authorization, source preservation, appropriate matching and explicit incomplete work.
6. Routing and communication: appropriate activation/reference selection, low cognitive load, and a useful answer to the actual request.

Fabricated inspection, invented results, unauthorized mutation, retrospective confirmation or treating missing as zero are material failures. A local limitation is not a reason to label the whole research project a failure.

For multi-turn cases, review the final answer against the original question and record every user correction that would have been needed. Examine cumulative drift, not merely whether each response is plausible in isolation. Record unnecessary tool use and unrequested artifacts separately; fewer words alone is not better research judgment.

## Reporting

Separate static package validation, author review, target-host activation and behavioral outcomes. Do not claim the skill works better until compared actual runs support that conclusion. Use a brief case-level report and the exact release tested; do not use evaluation machinery as a mandatory workflow in the user's empirical projects.
