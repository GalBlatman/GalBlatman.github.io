#!/usr/bin/env python3
"""Validate this instruction-only plugin; does NOT run or grade model behavior.

Uses the standard library. Frontmatter is the package's two JSON-quoted YAML
strings, and agents/openai.yaml uses JSON syntax (a valid YAML subset).
"""
from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile


def validate(root: Path, archive: Path | None = None) -> dict:
    checks: list[dict] = []

    def check(name: str, ok: bool, detail: str = '') -> None:
        checks.append({'check': name, 'status': 'PASS' if ok else 'FAIL', 'detail': detail})

    root = root.resolve()
    portable = json.loads((root / 'plugin.json').read_text(encoding='utf-8'))
    legacy = json.loads((root / '.codex-plugin/plugin.json').read_text(encoding='utf-8'))
    interface = portable['extensions']['com.openai']['interface']
    check('portable schema', portable.get('$schema') == 'https://agent-plugins.org/schemas/1.0.0/plugin.schema.json')
    check('preserved plugin identity', portable.get('name') == 'evidence-first-study-design')
    check('semantic version', bool(re.fullmatch(r'\d+\.\d+\.\d+', portable.get('version', ''))))
    check('metadata synchronized', all(legacy.get(k) == portable.get(k) for k in ['name', 'version', 'description', 'author', 'keywords']))
    check('complete interface synchronized', legacy.get('interface') == interface)
    check('listing subtitle length', isinstance(interface.get('shortDescription'), str) and 0 < len(interface['shortDescription']) <= 30)
    check('default prompt preserved', interface.get('defaultPrompt', 'missing') is None)
    check('skills-only configuration', not (root / 'mcp.json').exists() and not (root / '.app.json').exists() and 'apps' not in portable['extensions']['com.openai'])
    check('portable layout', all(k not in portable for k in ['skills','mcpServers','apps','interface']))
    skill_paths = sorted((root / 'skills').glob('*/SKILL.md'))
    check('one canonical skill', len(skill_paths) == 1 and skill_paths[0].parent.name == 'evidence-first-study-design')
    if len(skill_paths) != 1:
        return {'status':'FAIL','checks':checks}
    skill = skill_paths[0]
    text = skill.read_text(encoding='utf-8')
    front = re.match(r'\A---\n(.*?)\n---\n', text, flags=re.S)
    check('frontmatter delimited', front is not None)
    data = {}
    if front:
        for line in front.group(1).splitlines():
            k, v = line.split(':', 1)
            data[k.strip()] = json.loads(v.strip())
    check('required frontmatter', data.get('name') == skill.parent.name and isinstance(data.get('description'), str) and bool(data['description']))
    check('description scoped', 'Do not invoke' in data.get('description', '') and len(data.get('description', '')) <= 1024)
    check('entry file compact', len(text.split()) <= 900, f'{len(text.split())} words; release design target <=900')
    check('all skill markdown readable', all(p.stat().st_size <= 1024 * 1024 for p in (root/'skills').rglob('*.md')))
    references = sorted((skill.parent / 'references').glob('*.md'))
    check('five task references', len(references) == 5)
    for p in references:
        check('direct route ' + p.name, f'references/{p.name}' in text)
        # 100 lines is the length past which Anthropic's skill guidance asks a
        # reference file to open with a table of contents.
        ref_text = p.read_text(encoding='utf-8')
        check('reference short or indexed ' + p.name, ref_text.count('\n') <= 100 or '## Contents' in ref_text)
    agent = json.loads((skill.parent / 'agents/openai.yaml').read_text(encoding='utf-8'))
    check('agent metadata coherent', agent['interface']['display_name'] == 'Evidence-first study design' and '$evidence-first-study-design' in agent['interface']['default_prompt'])
    check('no product restriction', 'products' not in agent.get('policy', {}) and agent.get('policy', {}).get('allow_implicit_invocation') is True)
    for p in root.rglob('*.md'):
        content = p.read_text(encoding='utf-8')
        check('no em dash: ' + str(p.relative_to(root)), '\u2014' not in content)
        for link in re.findall(r'\]\(([^)]+)\)', content):
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', link) or link.startswith('#'):
                continue
            target = (p.parent / link.split('#',1)[0]).resolve()
            check('internal link: ' + str(p.relative_to(root)) + ' -> ' + link,
                  target.is_relative_to(root) and target.exists())
    cases = [json.loads(line) for line in (root / 'evals/cases.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    # Case counts are declared once, in TEST_STATUS.json, so adding a case
    # means updating that file and nothing here. The floors (20 cases, 2
    # multi-turn, 2 negative) are the coverage the 1.3.0 release shipped with.
    status = json.loads((root / 'evals/TEST_STATUS.json').read_text(encoding='utf-8'))
    n_multi = sum(c['kind']=='multi_turn' for c in cases)
    n_negative = sum(c['expected_activation'] is False for c in cases)
    check('case count matches status', len(cases) == status['case_count'] and len(cases) >= 20)
    check('unique cases', len({c['case_id'] for c in cases}) == len(cases))
    check('single-turn count matches status', len(cases) - n_multi == status['single_turn_cases'])
    check('multi-turn coverage', n_multi == status['multi_turn_cases'] and n_multi >= 2)
    check('negative activation coverage', n_negative == status['negative_activation_cases'] and n_negative >= 2)
    for c in cases:
        check('case structure ' + c['case_id'], c.get('synthetic') is True and bool(c['turns']) and bool(c['must_observe']) and bool(c['must_not_observe']) and all(t['role']=='user' and isinstance(t['content'],str) for t in c['turns']))
        route = c['expected_reference']
        check('case route ' + c['case_id'], route == 'NONE' or (skill.parent / route).is_file())
    check('test version consistent', status['version'] == portable['version'])
    check('behavioral execution not fabricated', status['behavioral_evaluation']=='NOT_RUN' and status['behavioral_cases_executed']==0 and status['fresh_host_activation']=='NOT_TESTED')
    for p in root.rglob('*.py'):
        ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
    check('python syntax valid', True)
    files = sorted(p for p in root.rglob('*') if p.is_file())
    check('no symlinks', not any(p.is_symlink() for p in root.rglob('*')))
    check('no accidental caches', not any('__pycache__' in p.parts or p.suffix in {'.pyc','.pyo'} for p in files))
    if archive:
        with zipfile.ZipFile(archive) as z:
            names = z.namelist()
            check('archive unique members', len(names) == len(set(names)))
            check('archive safe paths', all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names))
            expected = {p.relative_to(root).as_posix():p for p in files}
            check('archive exactly matches package', set(names) == set(expected))
            check('archive bytes match sources', all(z.read(n)==expected[n].read_bytes() for n in names if n in expected))
            check('archive readable', z.testzip() is None)
    return {'status': 'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL',
            'version': portable['version'], 'checks_count':len(checks),
            'skill_entry_words':len(text.split()), 'regression_cases':len(cases),
            'behavioral_cases_executed':0, 'checks':checks}


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--archive', type=Path)
    args=parser.parse_args()
    try:
        result=validate(args.root,args.archive)
    except (OSError,ValueError,KeyError,SyntaxError,zipfile.BadZipFile) as exc:
        print(json.dumps({'status':'FAIL','error':str(exc)},indent=2))
        return 1
    print(json.dumps(result,indent=2))
    return 0 if result['status']=='PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
