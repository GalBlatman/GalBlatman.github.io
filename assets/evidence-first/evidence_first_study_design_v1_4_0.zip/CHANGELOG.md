# Release notes

## 1.4.0

- One skill: a short router and five task references (explore and synthesize, design and confirm, build, audit and repair, literature and contribution, worked examples).
- Rules cover question framing, locating variation, registered tests, collection prompts, evidence and coding, identity and joins, bounded repair, execution audit, reading results and choosing hypotheses.
- Examples are synthetic and stated in general terms.
- The description excludes standalone prose editing, formatting, software testing and routine factual or statistics questions.
- 26 evaluation cases: 23 single-turn, 3 multi-turn, 5 of them negative activation cases.
- `evals/validate_package.py` checks packaging and case structure; `evals/test_validator.py` runs seven negative tests on that validator.
- Behavioral evaluation is NOT_RUN. No behavior claim is made for this release.
