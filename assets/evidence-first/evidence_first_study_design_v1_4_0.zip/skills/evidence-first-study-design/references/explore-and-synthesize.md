# Explore and synthesize

Use for theory development, reading results, explaining proxies, or deciding what an exploratory pass should teach. Do not turn this reference into a checklist the user must complete.

## Keep the account cumulative

Start with the question without its preferred answer and the accumulated observations. Consult the existing project account when a consequential recommendation depends on prior decisions; use the supplied context for a focused question. Keep distinct: what was observed, the working explanation, credible alternatives, dimensions examined, dimensions not yet examined, and explicit limits on action. Update an existing account only when authorized. Do not require another state file.

A new finding may add to, qualify, contradict, or leave the explanation unresolved. Say which, and preserve the rest of the picture. A narrower empirical pass is acceptable when its learning purpose and return to the broader question are explicit. A new mechanism or adjacent topic is not automatically a better project. A valid contradiction should change the account; an unavailable comparison should change what can be claimed about that comparison. Ask what observation would show the question itself is misconceived: leaving on that observation is a decision, and leaving any other way is drift.

Before several follow-ups on the same lead, ask whether the next one changes an important interpretation or merely generates another version of a known association. If several designs encounter the same obstacle, inspect their shared roster, source, boundary or independent variation before launching another. Do not make the researcher restore the question repeatedly. Check the project account before calling a result new: a restated result is a replication, and the reason the earlier line closed still applies.

## Read observations at three levels

1. **Observation:** the measured fact, denominator, population, period, boundary and support. Distinguish an imprecise association, little variation, equivalence, and an unavailable comparison.
2. **Context:** what the actors actually do and what the records establish about roles, obligations, resources and available actions. Do not invent context to make a coefficient intelligible.
3. **Theory:** which construct the measure could represent, how it enters the connected explanation, and what competing account could produce the same observation.

Integrate these in readable prose rather than repeating three labeled paragraphs for every cell. Measured decline is a fact even when its intention or cause is unknown. A formal field can be informative without identifying the operative actor: recorded contact is not automatically relationship manager; legal owner is not automatically independent decision-maker.

## Interpret proxies rather than assign labels

For consequential proxies, define the quantity and identify plausible interpretations only when they change the reading. Assess their fit; do not list every conceivable construct or pick one because the favored story needs it. A variable may serve different roles at different times, or represent several compatible processes. State the discriminating evidence.

A production measure is not directly managerial effort, competence or investment allocation. Size may reflect scale, indivisibility or system importance, but does not establish adjustment cost. An investment may upgrade capability, meet a requirement and reinforce activity-specific commitment simultaneously; it is not automatically symbolic compliance or sunk lock-in. Participation is not dependence. Ownership shares are not voting rights. Noisy operationalization does not justify claiming the underlying construct was tested.

A construct is a family of measures, and a result on one member is a result on that member. Before a statement about the construct or the research question, say for each relevant member whether it was compared against the explanatory condition, seen only as a trend over time, or not examined, and scope the statement to what was actually compared. No difference on one proxy is not a finding about the construct. Use a small table only when it makes the gaps easier to see.

Inspect ratios' numerator and denominator separately. A rising share can reflect more numerator, less denominator, or both. Keep algebraic alternatives from masquerading as independent corroboration. Distinguish response choice, structure, utilization, provision and consequences if the theory does. A measure may become a starting condition in the next period; that does not establish feedback without the relevant sequence.

Give a provisional judgment when justified: which interpretation currently fits better, why, what does not fit, and what would change the assessment. Do not require premature theory selection, but do not impose permanent even-handedness. A short inference is useful when its assumptions are explicit.

## Preserve a process, not a collection of effects

Describe the actors, what each can choose, the relevant conditions, alternatives, consequences and feedback. Distinguish choices from changes imposed by others or by a system. Specify a conditional relationship when the theory claims one; two main effects do not test that relationship. A statistical interaction alone does not establish the behavioral process. No fixed template or industry partition applies.

Compare form, extent, speed and eventual occurrence separately. A slower realization can reflect the same mechanism, not a new boundary condition. A finite observation window cannot establish an eventual outcome. If the explanation specifically predicts timing, timing evidence can challenge it. Otherwise restate an outcome worded as delay or postponement as which response is selected or how much changes. A rule may precede a decision, formalize an earlier choice, or alter implementation; first observed decision evidence is not necessarily the decision date.

Think in combinations before isolating associations: what circumstances accompany each response pattern? Use sequences, countercases and contrasts across units, within units and over calendar time. Common shocks, clustering and joint decisions matter for interpretation. Broad summaries and detailed histories are complementary.

## Explore in thin, useful laps

A thin look across the relevant parts of the phenomenon can prevent one promising detail from taking over. Do not require every part to be complete before learning from any part. Breadth is not a mandate to calculate every cross-product. A requested matrix or PCA is legitimate exploration: preserve its declared purpose, meaningful units and variants, but do not equate components with mechanisms or use an arbitrary suitability cutoff to discard an estimable descriptive result. State what a sensitivity adds before expanding it.

A useful exploration prompt gives the question, neutral phenomenon description, inputs, valid quantities, requested outputs, permissions and uncertainty handling. Give collectors enough conceptual definitions to classify correctly, but not a preferred answer they do not need. Excluding interpretation from a collector task does not exclude it from the analyst's subsequent synthesis.

Show a first meaningful output early when tools support it. If an implementation rule eliminates the central question or much of the planned work, announce the loss before completing peripheral outputs. Continue independent parts, preserving unknowns and contrary observations. Do not invent universal sample floors, untouched holdouts or sealed plans for discovery. Reproducibility requires saved sources, code and relevant choices, not necessarily a ledger of every incidental operation.

Independent tracks may run in parallel only when their inputs are independent and their writes cannot collide. Otherwise stage them by dependency. An optional second reader should first receive the same underlying evidence without the first reader's conclusion; compare readings before reconciling. Give each of the other reader's points a verdict with a reason (take, take in part, reject); agreeing with every point is a warning sign. Do not invent another reviewer or claim independent validation from two summaries of the same source.

## Decide what follows

Ask for contrasts: observations that should be similar under the strongest account but differ, or should differ but look alike. Descriptive variation alone is not a theoretical anomaly. Ordinary economic, technical or administrative explanations deserve substantive treatment, not a generic confounder paragraph.

Give the next action a learning purpose. It may be synthesis with no new computation, a missing simple comparison, a bounded construction or repair, targeted source completion, or a registered test once justified. Say what it adds beyond completed work. A consequence measure may be missing while evidence about choices remains useful; do not let one absent field invalidate everything.

When a result disappoints, ask in order whether the problem is the measure, the unit, the construct or the link; each is a hypothesis to check, and a reading that predicts the surprising result directly has equal standing. If a proxy fails, consider an alternative operationalization, arrangement of existing evidence, unit, period or source that preserves the question. Make changes to meaning explicit. Do not keep moving definitions until evidence supports the favored explanation. Distinguish continued inquiry, parked avenue, unavailable design and contradicted prediction. Researchers own consequential closures and scope shifts; recommend them clearly when warranted, rather than silently imposing them.

Qualitative description, construct clarification and process documentation are legitimate outcomes. A critical causal test is not an entry ticket to every useful research activity. When uncertainty is consequential, preserve it; when a finding is reliable, do not hedge away the finding itself.
