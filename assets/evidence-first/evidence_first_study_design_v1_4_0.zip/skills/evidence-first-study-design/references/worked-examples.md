# Worked examples

These are synthetic teaching cases, not project findings or citable empirical evidence. Use only the relevant example. They illustrate judgment, not scripts to copy into every answer.

## A measured phenomenon with uncertain intent

**Input:** Among 40 continuing production lines, 12 cut utilization by more than half; whether managers intended to defer closure is unknown.

**Useful response:** Reduced use while retaining capacity is measured for 12 of 40 lines. This separates deployment from retention. Deliberate postponement is one explanation, not an observed fact. Compare how this fits the rest of the project before naming the next missing piece.

**Avoid:** Calling lower utilization merely a possibility, or announcing strategic postponement as established.

## One quantity, several constructs

**Input:** Large units are retained more often. What does size measure theoretically?

**Useful response:** Physical scale is measured. Economic efficiency, indivisibility and system dependence are plausible but distinct readings. Explain their implications for the current mechanism; compare absolute size with relative importance when the data support it. Do not automatically call size an adjustment cost or demand a new regression.

## A new observation should refine the account

**Input:** A project asks how organizations adapt under new obligations. Prior evidence shows both internal modification and external sourcing. New evidence shows legal-owner changes.

**Useful response:** Ownership change may add a route of adaptation. Preserve the other routes and distinguish identity changes, transfers within a parent and exits across organizations. It does not automatically turn the project into a study of acquisitions.

## Sound prompt, no obligatory amendments

**Input:** An exploratory task already defines grain, counts, missing values, source provenance, written outputs, and no-network/read-only boundaries.

**Useful response:** Approve unchanged if no material ambiguity affects the object. A useful unrequested extension can wait. Do not require hashes, a holdout or five robustness versions.

## A legitimate one-to-many join

**Input:** Three verified components attach to one unit.

**Useful response:** Three relationships may be correct. Retain the component-unit table, define how component status is aggregated, and ensure output is counted once. Mark ambiguity only when candidate identities or attributes conflict, not merely because more than one component exists.

## Repair does not replace the question

**Input:** A sweep flags 5,000 rows. Recalculation changes two exits and several denominators; most production totals are unchanged. The user asks what comes next.

**Useful response:** Distinguish the footprint from changed findings, revisit the corrected interpretation, and return to the substantive comparison. Extend repair only for a demonstrated material dependency. Do not proclaim all findings invalid or launch a new full sweep.

## An unfavorable result is not a missing comparison

**Input:** In a supported within-site comparison, the predicted relation reverses. In a second comparison, the moderator is absent.

**Useful response:** The first challenges the prediction, subject to its actual scope and measurement. The second never assessed the interaction. Neither license automatic theory rescue nor closure of the broader question. Explain their different implications together.

## Timing, scope and authority

**Input:** Both groups adopt the required process; one takes three years longer. The first observed plan follows a rule, but the actual decision date is unknown.

**Useful response:** The observed speed differs; eventual occurrence does not. This can support the same process at different rates or challenge a timing prediction. The rule precedes the held plan evidence, not necessarily the decision. No automatic new mechanism follows.

## A ratio combines routes

**Input:** Favorable output rises from 20 to 40 with unfavorable output fixed at 80, or stays at 20 while unfavorable output falls from 80 to 40.

**Useful response:** Both end at a one-third favorable share, but only the latter contracts the unfavorable activity. Name the share's construct and preserve components if the theory distinguishes addition and contraction. Do not infer effort, capability or causal displacement from the ratio alone.

## One null proxy is not a null construct

**Input:** Dependence is measured three ways. Revenue share shows no difference between exposed and unexposed firms; contract length has only been plotted over time; switching cost has not been examined.

**Useful response:** One member of the family was compared and shows no difference; one is a trend that cannot be attributed; one is unexamined. Say that about revenue share, not about dependence. The step that teaches most is usually the trend-only or unexamined member, not another specification of revenue share.

**Avoid:** Writing that dependence does not respond.

## An institutional comparison disappears

**Input:** A collection run finishes 60 peripheral tables, but a timing rule excludes all intended lagged comparisons.

**Useful response:** Lead with the missing central work. Distinguish retrospective substantive ordering from knowledge available at the time; continue valid independent outputs and revise the timing rule only with authorization. A technically finished run is not a completed research task.
