# Literature and contribution

Use when a paper should inform a research decision, the user asks what is theoretically interesting, or findings are being developed into a manuscript. Do not impose manuscript positioning on a narrow factual or editing request.

## Read to learn, not to defend

State the live uncertainty a paper might resolve, when there is one. Read argument and empirical execution together. A paper can introduce an unanticipated distinction; not every useful reading needs a preregistered expectation. Afterwards distinguish what it proposes, documents, tests and leaves open, and what changes in the question, explanation or design.

Evaluate work by claim, evidence, relevance and quality, not venue or disciplinary membership alone. Distinguish theory already proposed, phenomenon already documented and relationship already tested. Adjacent work can supply an explanation or expose a mistaken setting premise. Say whether the attainable contribution is an extension, qualification, challenge or application based on substance. A new setting or label is not enough, but a familiar explanation can leave consequential questions unresolved.

Read full sources when available and record access limits: original inspected, author version, abstract, secondary report, or not found. Do not claim an original operationalization from a theoretical citation or a later adaptation. Record the measure's exact scope, units, period, denominator and relevant edition. Working-paper results apply to the edition inspected. A legal or technical document can establish a rule, not an organizational motive or mechanism.

Use literature to generate distinctions and credible alternatives, not only rejection gates. A prior paper may remove a novelty claim without settling the wider question. Preserve what the user supplied; identify external additions rather than silently replacing the source's framing. Review prior project closures at their actual scope, including corrections, before treating a literature implication as already disproved.

## Develop the explanation and contribution together

Keep separate: what predicts a pattern, why it predicts it, and what this changes in our understanding. A robust coefficient does not resolve those questions simultaneously. Build from the accumulated empirical picture and the nearest research, not the newest striking result.

Specify actors, choices, relationships and conditions. Translate consequential proxies into constructs and distinguish plausible readings before promoting an association. A connected process can be supported in part without proving every link. A novel phenomenon, improved construct, documented process, replication addressing a consequential uncertainty, or sharper scope can be worthwhile. No single critical causal test is a universal entry requirement.

Ask whether existing accounts explain the whole pattern or merely accommodate it. A theoretical anomaly is relative to an account's actual implications, not simply a model residual. Give ordinary explanations their strongest form. Where two accounts imply a useful difference, identify the discriminating observation. Where they do not, do not manufacture a contrast solely to claim novelty.

## Decide whether a finding should become a hypothesis

A familiar association can be a baseline expectation rather than the lead hypothesis. It can still deserve a hypothesis for a necessary logical step, consequential replication, boundary or relationship the literature leaves unsettled; state that job. Do not promote coefficient size, robustness or observed significance into theoretical importance.

Before formalizing a prediction, ask: what is already expected, what support would add, what failure would teach, and what evidence can assess the claim? A discriminating prediction is especially valuable when choosing between mechanisms. It is not the only legitimate form of research. Do not require a phenomenon-driven or qualitative study to fabricate hypotheses to proceed.

Theory development and observation can iterate. Date predictions written after observing patterns and identify what was seen. Further analysis of the same data does not become an untouched confirmation by being placed in a new prompt. Match any confirmation strategy to the claim and disclose reuse.

If the evidence supports only a description, retain it as a description and explain why it matters. If a mechanism remains a working interpretation, name its strongest alternative and the evidence needed to distinguish it. Provisional prioritization is permitted; premature certainty and permanent refusal to judge are not.

## Write and decide

Organize the manuscript around the theoretical question and the work the evidence performs. A process account need not be recast as a regression paper. Avoid both jargon that renames ordinary behavior and claims of novelty based on caricaturing prior theory.

Use plain language and material caveats. Assert a sound observation while locating uncertainty in cause, measurement scope or generalization. Reconcile a new reading with previous findings rather than replacing the project story on each turn. Do not create more analysis simply because synthesis is harder. The next step should address the most consequential unresolved claim within the project's resources, not the largest remaining dataset.
