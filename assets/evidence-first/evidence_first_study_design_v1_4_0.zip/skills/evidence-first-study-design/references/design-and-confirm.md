# Design and confirm

Use to specify a comparison, assess its feasibility, or register and audit a test of a developed prediction. The standards below apply to the claim being made, not every exploratory step.

## Frame the question and comparison

State the question without its preferred answer, what a reader would understand differently, the explanatory level, what is known versus inferred, and the strongest existing expectation. A setting alone is not a contribution. If removing the favored explanation leaves nothing to ask, it is an argument, not a question. Say whether the planned comparison observes the explanatory level or a proxy one level down. Ask what misunderstanding is corrected, which actors and activities would explain the phenomenon, and what the real sequence is before reducing it to a coefficient. These retain the framework's Zuckerman, Stinchcombe and Langley prompts as questions, not substitutes for reading the relevant literature.

Give plausible accounts their strongest form, including routine, economic, technical and administrative accounts. Compare their expectations in direction, form, timing, persistence, location or scope. Each comparison should establish a pattern, distinguish accounts, support a process claim, or separate behavioral change from measurement or boundary change. Several weak versions are not a strong comparison. Pick population, unit and period from the question, not just the workbook at hand. For a specified comparison, write what each possible result would mean before building it; if every result would leave the central uncertainty untouched, redesign.

Define constructs, measures and their alternatives. Determine whether two proposed mechanism indicators are distinct or nested by construction. Two regressors cannot identify processes the measures do not distinguish. In choice-set designs, report whether the explanatory attribute varies among the alternatives within each set. Between-set variation does not supply within-set choice information.

## Locate the relevant variation

Identify what varies, its level, the source establishing each side, who is exposed, and the independent decisions or events carrying it. Count overlap, clustering, support and eligible follow-up. Hundreds of rows can represent one transaction or rule. An observed attribute versus an unknown attribute is not a verified contrast.

Before major collection, write a few lines on feasible variation, sources, comparison, independent units, response evidence, and plausible identification obstacles. Use existing evidence instead of demanding another pilot. Counts can be verified, estimated or upper bounds; label them. No universal sample floor applies. A descriptive study need not meet a causal estimator's requirements.

Separate source existence, access, field content, period coverage and support for the intended comparison. Locate the distinguishing attribute itself: a quantity dataset may not identify eligibility, governance, legal status or authority. Verify premises central to the design in primary materials rather than relying on memory. Name a missing source without asserting unverified contents.

Plan manual access or licensed retrieval when needed, with permission and effort limits appropriate to the task. Successful access is not usable evidence. When ideal evidence is unavailable, consider a different arrangement preserving the theoretical distinction; disclose the changed inference. Do not default to either unmeasurable or close enough.

## Time, boundary and eligible observations

For events, establish what changes for the focal entity, when it changes, and whether exposure continues. Announcement, proposal, adoption, effectiveness, enforcement, actual decision and physical implementation are not interchangeable. Record intervals when exact dates are unknown. A demand predating the earliest held plan predates that evidence, not necessarily the choice.

Use pre-existing information when constructing exposure to explain a subsequent response. Retrospective lagged description is permissible when substantive periods and identities are established and the earlier measure is not built from later outcomes. Missing publication dates limit claims about real-time knowledge, not automatically historical ordering. Exclude pooled future-window measures and backcast identities from prospective claims. Preserve revision and vintage uncertainty.

Compare calendar time, elapsed follow-up and starting conditions. Do not treat a unit still operating at a window end as proof it never withdraws. A speed difference is not automatically a boundary condition on occurrence, but can matter for a timing claim. Align denominators and activity boundaries; for example, what an organization sells, what it produces itself and what it buys in are not interchangeable populations.

A reference-period classification selects entities observed in that period. Show unknowns and survival conditions in other periods. Check for tautological groups defined using the behavior later compared. Where a benchmark is intended to represent pre-existing context, exclude the focal unit and entrants from the same cohort and distinguish prior from concurrent values.

Define a shuffled or permuted benchmark before running it: which endpoints move, what is held fixed, whether duplicates are allowed. Preserve each partner's number of ties when asking whether ties favor a kind of partner, or popularity will pass for preference; where no clean benchmark exists, report the comparison without one. Rank-based bins can be dominated by a few large units and hide a monotone pattern, so inspect the units inside an irregular bin and bands defined on the measure itself. Choose cases for detailed follow-up by a rule set beforehand, not by which stories are most striking.

## Register a specified test

Exploration does not require an untouched holdout. Preserve what was searched and seen, including uninformative results, with provenance proportionate to the work. Do not present exploratory patterns as confirmed predictions.

Before seeing the results of a specified prospective test, record in a dated registration:

- The predictions, competing accounts, planned comparisons and what each possible result would teach.
- Measures, population, unit, boundaries, versions, exclusions, estimator or reading rules, uncertainty treatment and the independent support required for this claim.
- Data already examined and their role. Specify independent evidence or an explicit strategy addressing reuse; do not label used evidence untouched.
- Access and feasibility limits, resource stops, and what would make the explanation insufficient. Distinguish those from statistical or interpretive support requirements. If collection stops once the requirement is met, later counts are floors.
- Code outputs and evidence artifacts that will allow an execution audit.

Do not lower a predeclared evidence requirement to fit convenient access. If a verified upper bound rules out the specified test, amend the comparison explicitly or stop that test; this does not close the wider question. Feasibility work can precede registration if measurement rules and any outcomes inspected are recorded. An open descriptive pass needs a learning question, not a conclusion for every possible result.

Write amendments into the current dated registration before implementing them, retaining earlier versions and amendment reasons. Record any numbers already seen. Code should identify the current substantive rules it implements. Do not smuggle redesign into a coding correction. If two registered reading rules disagree, report both and their support rather than adding an unplanned specification to break the tie.

## Read the test at its actual scope

A result may weaken an extreme claim, narrow a range, reveal conditional variation, or be uninformative. An imprecise estimate is not evidence of equality. Changing aggregation, centering, denominators, ties or samples can change the estimand; a sign reversal does not automatically correct the earlier result.

Keep distinct: a failed prediction, invalid measure, unavailable comparison, failed access, and a result fitting several accounts. Evidence against a prediction should alter its explanation. Poor access changes the access plan. Several plausible explanations call for a better contrast, not necessarily a larger sample of the same kind.

Read the chain again: question, explanation, expected observation, comparison, available records, warranted conclusion. State where meaning changed. Execution compliance and theoretical adequacy receive separate verdicts. Use the build/audit reference for file-level verification; do not claim an audit from a report summary alone.
