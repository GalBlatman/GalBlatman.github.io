# Build, audit and repair

Use for collection-prompt review, measurement construction, execution audit and targeted corrections. Choose the relevant section; this is not an instruction to audit every project file.

## Review a prompt without manufacturing work

Identify its job, learning purpose, authorized inputs, quantities and expected outputs. Distinguish four kinds of comment:

| Comment | Action |
| --- | --- |
| Wrong quantity, invalid attribution, material unsupported inference, or unauthorized action | Correct before that dependent work runs |
| A limitation that changes interpretation but not the requested calculation | Record beside the result; do not automatically block execution |
| A valuable extension answering a different question | Park it for the researcher's later decision |
| Stylistic preference or optional elaboration | Do not make it a condition of proceeding |

Approve unchanged when sound. Review quality is consequential error prevention, not amendment count. Do not repeatedly append new requirements just because they could be useful. Explicit user constraints govern. A missing file is not an empirical negative and does not justify halting independent parts.

## Write or execute a bounded task

The prompt needs the question, units and accessible inputs, neutral definitions, outputs, authorization and failure handling. Reuse accepted definitions and code. Give the collector sufficient conceptual distinctions to code correctly, but not a favored explanation unnecessary to extraction. A no-interpretation rule applies to that collector output, not the analyst's later reading.

Label a delegated run EXPLORE, BUILD or TEST so that its audit knows which standard applies; the labels do not prohibit descriptive support tables in a build or require an invariant sequence. For registered execution follow its counts, saves, exclusions and checkpoints. For exploration use lightweight saves and interpretable intermediate output. No mandatory hashes, frozen schemas, holdouts or sample floors unless justified by the task.

Keep source artifacts and enough provenance to reproduce relevant results. Record scope, units, versions, choices and failures; a log of every imported module is unnecessary. Show coverage in the unit appropriate to the claim, including independent groups and denominator quantities, not merely successful join rows.

No favored substantive result is required. But if a rule or data problem removes the central comparison or a substantial share of planned work, report that immediately and lead the final report with it. Continue independent work. Make routine reversible implementation decisions within authorization; isolate consequential unresolved definitions instead of silently narrowing the question or asking the researcher to approve every detail.

For external retrieval, identify permission, source, known limits, credentials availability and stopping conditions without recording secrets. Distinguish planned quota completion from unexpected access failure and NOT_REQUESTED from not found. Do not attempt forbidden paths or unapproved services. Local unrestricted work needs no external-access plan.

## Evidence and coding

Unknown, NOT_VERIFIED, NOT_OBSERVED and failed retrieval never become zero. Absence requires complete inspection at the scope asserted: field, schedule, document or relevant referenced materials. Code non-response only with affirmative evidence. Referenced but unavailable documents remain NOT_RECOVERED; uncertain measures they could change remain unverified. Log every discrepancy with a previously accepted code, continue unaffected work, and never silently overwrite accepted inputs.

Preserve a locator, source, vintage and access status for judgment-based codes, and source/transform lineage for derived fields. Distinguish organizational claims, independent evidence and schema instructions. Record stated reasons as attributed statements, never proof of motive. Use neutral field names for what is observed; do not build accountability, buffering, intention or legitimacy into a label.

Keep primary/proxy, censored/uncensored, legal-owner/parent and dated/retrospective versions distinct unless justified pooling is explicit. A recorded fact does not carry its neighboring construct: for example, a recorded asset does not prove a sunk commitment, a count of co-owners does not establish veto rights, and acquired, reported and currently in use are separate states. Preserve event dates when constructing recency measures.

## Identity, grain and joins

Establish what an identifier denotes before interpreting entries, exits or transitions. Preserve source ID, canonical ID, date, legal entity, parent at that date, mapping evidence and uncertainty. Similar normalized names, shared addresses, missing-value codes, shared representatives and convenient outcomes are candidate signals, not sufficient identity proof. Validate known matches, nonmatches and ambiguities.

Distinguish identity alias/succession from transfers of an interest between different entities, within-parent reallocations, between-group transfers and changes in physical activity. Do not merge legal entities because they share a parent or because a stake continues. Do not assign earlier assets to a later acquirer unless explicitly studying that retrospective boundary. Current parent names do not verify historic control.

Separate identity-caused join failures, source-scope differences and unresolved joins. Roles recorded in different sources need not coincide: for example, an owner need not be the party of record in a transaction, and a missing ownership record does not make the operator the owner. Keep confirmed and provisional ownership rules visible in downstream denominators.

Check intended cardinality before rejecting a join. Multiple components per unit, owners per asset or requirements per owner can be valid one-to-many relationships. Preserve the relationship table and aggregate by a defined rule to the analysis grain. Distinguish that from conflicting candidate identities or accidental Cartesian expansion. Never duplicate a physical quantity (output, volume, capacity) by multiplying relationship rows. A normalized key is not a new unit; report uniqueness, matching and totals before and after.

For shared assets, separate owner participation from common physical outcomes and do not assign later behavior to exited owners. Several unit rows may be one site-level transaction. Compute dependence at the level the claim is about: an entity's share of its own holdings, one stake as a share of the parent's holdings, and the parent's whole interest as a share of its holdings are different quantities and can point in opposite directions. Count each underlying interest once. Label whole-population and matched-subset outcomes separately, and match the boundaries of numerator and denominator before computing a rate or coverage.

## Other construction cases

Apply only the case that matches the data in hand.

- Networks: before computing measures, write down each network's nodes, edges, direction, weights and treatment of disconnected parts. Keep networks built from different relations separate, report each named measure as itself, and flag patterns a projection creates by construction.
- Relationship data: a tie no longer recorded may mean the tie ended with both parties still observed, one or both parties left observation, or follow-up is incomplete. Only the first is a change of partner.
- Rules and exposure: a characteristic that makes a rule relevant to a unit is not verified legal applicability; keep relevance, applicability and geography separate. Classify the condition an actor faced from what was documented then, and keep later events in a separate retrospective field.
- Grouped movement: when many units change the same way in one period, check for a single event at a higher-level unit before reading many separate decisions.
- Amounts: show original amount, absolute change and relative change together, and flag small bases.

## Identity-repair propagation and return to research

Name the finding or comparison the repair will restore and the authorized endpoint before expanding work. Keep four levels distinct:

1. A verified identity defect or source-key encoding difference.
2. Files or rows referring to the affected identifier.
3. Measures and aggregates shown to change after recomputation.
4. Inferences that change because those quantities changed.

A footprint is not an error count; a crosswalk is not a completed repair. Trace affected joins, eligibility, outcomes, denominators and exposure. Reconstruct denominators from unique corrected native interests, not sums of overlapping old entity totals. Parent totals may change through inclusion, weights or missed joins even if two IDs share a parent. Do not assume invariance.

Report saved before/after values for changed measures, explicit unchanged checks, reproduction gaps, and dependents not yet recomputed. For distributions, distinguish magnitude, ordering and category-composition changes; do not invent a single direction. Unknown is not unchanged. Do not call findings robust or overturned from the sweep alone.

Prioritize defects changing the focal comparison. Park other coverage improvements unless a demonstrated dependency makes them necessary. Stop the repair at its authorized endpoint, then return to the named research question: what changed, what remains and what that enables. Repairs may proceed alongside unaffected learning in separate write paths. Do not launch another general sweep by default.

## Audit execution, not just presentation

Open the actual artifact. If unavailable, identify what can be checked from the report and limit the verdict; never claim inspection or independent recomputation without doing it. Obtain the construction script and matching evidence when the audit depends on them.

For a registered test, compare the implemented substantive definitions, exclusions, groups, thresholds and stops to the latest registration and amendments. A new analytic rule is a deviation, not merely validation. Affected unregistered estimates are not confirmatory. Distinguish execution error from a design problem that an otherwise compliant result reveals.

Reconcile entities, units, codes, coverage, denominators and counts. Independently recount important reported cells where possible. A required comparison missing, duplicated, nonfinite or unestimable is not a pass because no numerical disagreement was found. State accepted, partially accepted or corrections needed for the audited scope. An audit is not permission to mutate source files.

Keep one traceable project record connecting evidence, interpretation and status. Findings need a reproducible artifact location and limitations; source and derived finding are not independent evidence. Record corrections to previously closed lines and revisit the arguments those corrections support. Separate contradicted, untested, unavailable and parked. A locator supports auditability, not truth by itself.
