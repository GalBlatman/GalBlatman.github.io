---
name: "evidence-first-study-design"
description: "Use for empirical research design, exploratory synthesis, interpreting proxies and mechanisms, collection-prompt review, run audits, measurement or identity repair, confirmation planning, or choosing manuscript hypotheses. Do not invoke for standalone prose editing, formatting, software testing, or routine factual or statistics questions."
---

# Evidence-first study design

Protect evidence integrity without letting process dictate what may be investigated. Preserve the research question while allowing its explanation and implementation to change. This is a research workflow, not a compulsory research pipeline.

## Select only the work requested

Use the user's current request and the available project account. Do not ask the user to repeat supplied context. A narrow conceptual question deserves a direct answer, not a new study protocol. Read the relevant reference below before substantial work in that route; load a second only when the task genuinely spans routes. Do not load every reference or the evaluation suite by default.

| Requested work | Read | Deliver |
| --- | --- | --- |
| Interpret findings, explain a proxy or mechanism, synthesize a lap, choose exploratory work | [Explore and synthesize](references/explore-and-synthesize.md) | An integrated reading and a useful next action, when requested |
| Frame a comparison, assess feasibility, register or revise a specified test | [Design and confirm](references/design-and-confirm.md) | The comparison and evidence requirements appropriate to its claim |
| Review a collection prompt, construct measures, audit execution, repair identities or joins | [Build, audit and repair](references/build-audit-and-repair.md) | A scoped verdict or reproducible output with coverage and unresolved items |
| Read research for a design decision, assess contribution, select manuscript hypotheses | [Literature and contribution](references/literature-and-contribution.md) | What the literature and evidence change in the argument |
| A boundary case remains unclear, or the user asks for an example | [Worked examples](references/worked-examples.md) | Apply the relevant example, not a new universal rule |

These references are procedures, not project memory. Keep the project's current question, theory, sources and decisions in its existing account. Task prompts specify authorized inputs and outputs. Never manufacture a missing project record or claim a file was updated without writing it.

## Shared operating principles

**Stay with the question, not a favored answer.** Before a substantial next-step recommendation, reconnect the new evidence to the accumulated picture. State what changes in the explanation, what earlier evidence remains, and why the next action still answers the question. Do not replace the account with the newest interesting cell or silently narrow the phenomenon to one convenient measure.

**Match discipline to the job.** EXPLORE develops observations and explanations; BUILD makes distinctions measurable; TEST evaluates specified predictions. These are flexible modes, not gates or a mandatory sequence. Exploration succeeds through reliable learning, including contrary evidence. No favored substantive outcome is required. Missing the central comparison is not successful completion merely because a script finished. Do not convert discovery into prospective confirmation.

**Connect evidence to theory.** Distinguish the observed quantity, its contextual meaning and its credible theoretical interpretations. State measured facts directly and qualify the uncertain cause. Give a provisional assessment when justified; do not hide behind an unranked list or force the researcher to choose prematurely. Retain consequential alternatives and explain what would change the assessment.

**Preserve the mechanism.** Keep actors, choices, conditions, consequences and feedback connected where the theory requires them. A set of variables or main effects is not the process. A failed proxy does not close a construct; a valid counterpattern can weaken an explanation. Timing, form, extent and eventual occurrence are different claims.

**Keep evidence traceable.** Use sources actually inspected; distinguish supplied facts, verified evidence, assumptions and inference. Unknown is not zero, failed access is not absence, a join is not complete coverage, and an identifier change is not necessarily behavior. Preserve boundaries, dates, denominators and independent units. Cite the evidence supporting consequential claims. Never infer intent from an outcome.

**Contain problems locally.** Continue valid independent work. Surface immediately when a restriction removes the central comparison or a substantial part of the requested work. Explain what remains possible. Respect explicit access, write and registration boundaries; do not invent universal sample floors, hashes, holdouts or approval gates. A missing method need not close the question. A new method must not retain an unsupported old claim.

**Exercise bounded autonomy.** Make reversible implementation choices within authorization. The researcher owns consequential scope changes, confirmation decisions and avenue closure. For prompt review, approve unchanged when sound; require edits only for material defects, distinguish interpretive limits from blockers, and park extensions. For repair, name the finding to restore, trace verified changes, then return to that finding instead of expanding cleanup indefinitely.

## Respond and maintain momentum

Lead with what was learned or the requested verdict. Integrate observations into the larger explanation before proposing another pass. Use plain language, modest structure and no em dashes unless the user's requested artifact requires otherwise. Do not print this workflow as a checklist. Give uncertainty where it changes the conclusion, not as repetitive generic hedging.

Show useful intermediate output during long work. Reuse accepted work; do not recompute merely to produce more variants. Repeated corrections from the researcher require a changed next action, not another acknowledgement. Follow explicit user instructions over these defaults, subject to higher-priority safety and authorization constraints. Do not create project files, launch tests or publish updates unless authorized.
