# Evidence-first study design 1.4.0

A single research-workflow skill with task-specific references, for empirical research in which part of the collection or analysis is delegated to an AI agent.

## Structure

- `skills/evidence-first-study-design/SKILL.md`: compact routing and shared principles.
- `references/explore-and-synthesize.md`: cumulative theory development and flexible discovery.
- `references/design-and-confirm.md`: comparisons, timing, feasibility and registered tests.
- `references/build-audit-and-repair.md`: prompt review, provenance, identity, joins and bounded repair.
- `references/literature-and-contribution.md`: literature use and contribution-bearing claims.
- `references/worked-examples.md`: synthetic examples, not empirical evidence.
- `evals/`: regression cases, rubric, a deterministic package validator and negative tests for that validator. Not loaded during routine research.

Reference paths above are relative to the skill directory. The main file links each directly. The skill creates no project dashboard or mandatory file scheme. It reuses the user's existing project account and authorization.

## Evaluation

Run `python evals/validate_package.py` from this package directory to check manifests, skill metadata, internal references, test-case structure and packaging constraints. It does not invoke a model or assess research judgment. Run `python evals/test_validator.py` to confirm the validator fails when the package is broken in seven specific ways. See `evals/rubric.md` for live-host behavioral evaluation and `evals/TEST_STATUS.json` for what was actually executed in this release.

Do not confuse a valid archive, successful activation and demonstrated research behavior. They are distinct checks. No ChatGPT or Codex behavior result is implied by this package.

## Privacy and dependencies

Instruction-only research workflow. No server, account connection, external dependency or data is bundled. Evaluation vignettes and worked examples are synthetic. The package validator uses the Python standard library.
