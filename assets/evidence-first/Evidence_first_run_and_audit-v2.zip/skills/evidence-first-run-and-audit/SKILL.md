---
name: "evidence-first-run-and-audit"
description: "Registers a test, writes or reviews the prompt for a collection or build agent, audits a checkpoint or finished run, traces data corrections and identity repairs, and keeps the project record, for an archival or document-based empirical research study. Use when an explore, build or test run is being specified, sent, checked or repaired, or when measures, entity matches, identifiers, joins or shares are being built from records. Works on its own; part of the evidence-first-study-design family. Not for software tests, CI pipelines or model-training checkpoints."
---

# Evidence-first study design: run and audit

One of three skills in the `evidence-first-study-design` family. This one covers Jobs 3, 5, 6 and 7 (registering a test, collecting and coding, auditing, recording) and holds the construction lessons. It works on its own for those jobs. Load `evidence-first-study-design` when the task reaches the research question, the design of a comparison (Jobs 1, 2 and 4) or how the project is steered across runs. Load `evidence-first-read-and-decide` when a result has to be interpreted or a hypothesis chosen (Jobs 8 and 9).

No em dashes in anything produced under this skill.

## The kind of run decides the weight of the prompt

Every agent run carries one label, explore, build or test, and the label fixes the standard its audit applies. Explore looks broadly and reports surprises. Build constructs measures and reports coverage. Test runs one registered comparison faithfully. Sealed plans, hashes, gates, checkpoints and stop rules belong to registered tests and major collections. Explore and build runs use containment instead: a missing variable, a failed match or a thin cell is marked and reported while everything unaffected is finished; the run stops only for a risk to source data, a need for access it does not have, or credentials. If a problem removes the central comparison or a large share of the intended work, that is the first line of the output; a script that finished is not thereby a task that succeeded. Such runs ask one question, send their first table early, and end with what was observed or built and what remains unknown. The collector gets the question, the phenomenon in neutral words, definitions sufficient to code correctly, and the instruction to preserve what does not fit. It is not given the working explanation.

## Job 3. Register the test

Match safeguards to the purpose of the analysis. Exploratory work may describe unusual cases, concentrated changes, sequences and differences without confirmatory sample floors or an untouched holdout. Preserve the entire search record, disclose post hoc choices, and do not present exploratory findings as confirmed hypotheses. Concentration is a descriptive finding during discovery; whether it limits generalization depends on the later claim. Confirmation requirements are not a gate on which phenomena may be investigated. Once a developed explanation is to be tested, separately register its comparison, independent evidence requirements and validation strategy, and treat data that shaped the explanation as unavailable for confirming it unless the registration says how that is handled.

Before examining the results a registered test will use, write into a dated registration file:

- The expectations table and which pattern speaks to which explanation.
- Reading rules stating what result would favour each explanation, and how much evidence is enough for the intended claim. Set evidence requirements from the claim and the comparison it needs. Use inspected cases to assess whether the records can supply that comparison and what obtaining them will require. Do not lower the evidence requirement to match convenient access; do not require a pilot when existing records already establish the relevant facts.
- The unit at which the claim operates, including the level at which observations share exposure or information. Evidence requirements follow the claim, not the available sample. Before authorizing the full analysis, count the units meeting the comparison's requirements, including period coverage and linkage, distinguishing verified counts, estimates, and upper bounds. The Job 2 feasibility statement (in the core skill) is the starting point for this count. A bounded feasibility inventory may establish it before test registration; state its measurement rules and record any outcomes inspected. If a verified upper bound falls below the evidence requirement, do not launch the full analysis or lower the requirement to fit; revise the comparison explicitly or stop that design.
- Feasibility gates (can the records be obtained) and stop rules (when to stop spending effort), kept distinct from the evidence requirements. State what a sufficiency stop implies for selection: later counts are floors.
- What would make the explanation insufficient.

When a registration is amended, write the amendments into the registration file itself before any script is written from it, keeping the superseded text and the reason for the change, so that one file is the current rule; a script written from a superseded version has not followed the registration.

Results between the registered outcomes are assessed, not dismissed: say whether they narrow a range, weaken an extreme claim, reveal variation across conditions, or tell us little. Anything registered after a result has been seen is dated, labelled as such, and says which numbers were seen. When two registered rules read the same quantity and disagree at the margin, report both readings and the support behind them; do not run a new specification to break the tie.

## Job 5. Collect and code

The collection prompt restates the rules every time; the agent has no memory of the last run.

Non-negotiable evidence rules:

- The search required to establish absence matches the scope of the absence claim. Document-wide absence requires the full relevant document and its included or referenced components; absence from a field or table requires complete inspection of that field or table. State the scope in the code.
- NOT_VERIFIED is never converted to 0. A failed retrieval route is never coded as absence; it is a route failure with the error logged.
- For entity and relationship matching, missingness codes, generic categories, and absence indicators cannot supply positive identity evidence. Keep verified identifiers, constructed name keys, and relaxed candidate links distinct. Validate known matches, known nonmatches, and ambiguous cases, including unrelated units sharing an absence code. A shared address or contact person is a shared recorded attribute, not by itself proof of the same organization or organizational continuity.
- Non-response is coded only on affirmative evidence.
- Every coded judgment carries a locator and an access level. A field derived mechanically from a structured source carries its source and transform lineage instead. Text authored by the organization, by an outside reviewer, and by a form's schema are distinct provenance and are never merged.
- Supporting documents referenced but not recovered are NOT_RECOVERED after the planned checks; measures the document could change stay NOT_VERIFIED; a code that no further document could overturn stands.
- Sets built under different rules (primary and proxy; censored and uncensored histories) are reported separately and pooled only with an explicit, defended reason.
- No motive is coded. No prediction is scored before classification is complete. Unexpected patterns are flagged, not explained.
- Name fields, groups and labels for what the record shows, never for the explanation under consideration. A label that carries a mechanism (who is accountable, who decided, what was buffered) builds the explanation into the variable; describe the documented requirement, role or event and keep the interpretation outside the data. The same holds for constructs: a share of transactions handled by one partner is a transaction share, not tie strength; size and tenure are size and tenure, not status; a change in recorded activities is not yet a change in capability. Whether the recorded quantity stands for the construct is argued in the reading.
- Log every discrepancy with a prior code. Continue unaffected work; stop dependent work when the discrepancy could change units, eligibility or interpretation. Never silently overwrite accepted inputs.
- Checkpoints at registered counts; recovery saves at a fixed cadence; stop and report at a checkpoint. This applies to registered tests and major collections. Exploratory and build runs follow the containment rule stated above.
- Output: designated, saved evidence artifacts appropriate to the study, with a traceable log and a short report containing the counts first and no interpretation. Every reported number must be reproducible from those artifacts.

When collection depends on an external system (an API, a portal, a licensed source), the prompt carries a declared access plan: known quotas, permissions, a credential check before the first request (never recording the secret itself), expected coverage, and the stopping condition. A known quota reached according to plan is partial completion, with every unretrieved unit NOT_REQUESTED; an unexpected rate limit or a credential that is absent or not loaded is an access failure, logged as such and retried after the environment is fixed. Neither is an empirical negative. A boundary the prompt sets (no network, read-only inputs) is never routed around. Unrestricted local files need no access plan.

The script or prompt that implements a registered test restates the registered rules it applies (definitions, exclusions, thresholds, groups, stopping rules) in its header, so the audit can compare them to the registration.

Prompt skeleton, in this order:

1. The label (explore, build or test) and the purpose in one line.
2. The question and the phenomenon in neutral words.
3. Units and their source; what the run may read and where it may write.
4. Fields with allowed values and definitions.
5. The evidence rules above, restated.
6. What to do when something fails: containment for an explore or build run, registered checkpoints, saves and stop rules for a test.
7. Outputs: the saved artifacts and sheets, the log, and a short report with counts first.
8. "No interpretation, no motives, no em dashes."

Reviewing a prompt before it runs. Identify its job, its learning purpose, its authorized inputs, the quantities it will produce and its outputs. Then sort every comment into one of four kinds and say which:

| Comment | Action |
|---|---|
| A wrong quantity, an invalid attribution, an unsupported inference the result would rest on, or an unauthorized action | Correct before the dependent work runs |
| A limit that changes how the result is read but not what is computed | Record beside the result; do not block the run |
| A useful extension that answers a different question | Park it for the researcher |
| A stylistic preference or an optional elaboration | Not a condition of proceeding |

Approve a sound prompt unchanged. Review quality is errors prevented, not amendments made, and inventing a defect to justify a comment is a failed review.

Corrections and repairs. Name the finding or comparison a repair is meant to restore before it starts, and stop when that finding can be read again. Sweep for a defect once. Keep four things apart: a verified defect; the files and rows that refer to the affected identifier, which are a footprint and not an error count; the measures shown to change on recomputation; and the readings that change because those measures changed. Every instructed correction ends with "report before and after values from the saved file," then regenerate affected counts and summaries, and check whether an empirical example used in the argument must also change. A summary that says "applied" is not evidence that it was. What was not recomputed is unknown, not unchanged, and a sweep alone does not show that findings are robust or overturned. Other defects met on the way are parked unless the named finding depends on them.

## Job 6. Audit each checkpoint

Auditing execution and redesigning the study are separate acts. The audit gives an unambiguous verdict on whether the run followed its instructions. A design problem the result raises is flagged separately for Job 2 (in the core skill); the redesign then happens explicitly and is dated, never smuggled into a coding correction. An audit is not permission to change source files.

1. Open the file; do not audit from the summary. Retain the construction script and, for linked data, the matching ledger in the audit package. If a file, the script or the ledger is unavailable, limit the audit verdict to the checks possible and say which they were. Never report an inspection or a recount that was not done.
2. For a registered, scripted analysis, reconcile the rules the script implemented against the latest dated registration including its amendments: definitions, exclusions, thresholds, groups and stopping rules. This is a substantive comparison, not a textual diff. Any substantive analytic rule the registration removed or never contained (a definition, exclusion, threshold, group or stopping rule) is a violation, and the outputs it produced are exploratory, whatever they show; a validation check or an error-handling safeguard is not an unregistered rule. An explore or build run has no registration to reconcile; the remaining steps apply at the weight of the run.
3. Check that the frozen unit list reconciles to the registered one; codes use only allowed values; every absence has a search record matching its scope; counts in the report match the sheets; denominators are stated; nothing was interpreted.
4. Check the event timing and identity evidence required by Jobs 2 and 5, not just passing counts or joins.
5. Recount the registered cells yourself, from the accepted output and with a code path independent of the script. An audit that compares estimates must also fail when a comparison is missing, duplicated, nonfinite or unestimable; absence of a disagreement is not a pass.
6. Confirm that every reported number has a reproducible location in a designated, saved evidence artifact (a workbook sheet, a CSV, a ledger, a database extract, a document); a side calculation cannot silently become a finding.
7. Report accepted or not for the audited scope, with the corrections needed.

## Job 7. Record

Keep one traceable project record. Connect questions, ideas, sources, findings, decisions and corrections. Separate evidence from interpretation and from project status. Make the full argument and its unresolved parts easy to inspect. The account page described in the core skill is this record's front page, not a second record.

- Every finding carries source, location, vintage and limitation; each substantive finding identifies the sheet, table, document or source range that supports it, and each inferential claim also identifies the comparison that supports the inference. A locator improves auditability; it does not validate the claim.
- Record results the same day, with denominators, before they are discussed.
- Do not count a source and a finding derived from that source as independent evidence.
- Every closed line records why it closed (contradicted, contradicted at pilot scale, design could not identify the comparison, not tested, withdrawn) and what the closure does not establish.
- When a later check corrects a premise written into a closed line's record (a field said not to exist, a source said not to be public), add a dated correction to that record and revisit every argument the premise carried; the closure itself changes only if one of those arguments was load-bearing.
- Never report the record or its front page as updated without writing it.

The particular structure of the record (node types, link vocabulary, overview notes) is a project setting.

## Construction lessons to consider (conditional, each with when it applies)

These concern building measures, matching entities and recording what the records show. Comparison lessons are in `evidence-first-read-and-decide`.

- Preserve the distinctions the argument needs; combine measures only when the construct and its interpretation justify it. Report joint distributions on fully verified units and the missingness pattern among the rest.
- Vintage pairs (what a record said about year t when first printed versus what a later record says about year t) when the record itself may change; classify differences only from the source's stated reason.
- Define identity for the object being studied before matching across documents; a checklist of identity fields (type, amount, period, reference point, boundary, coverage) is an example to adapt, not a general rule.
- Report shares on both the verified base and the base with the relevant object present; name the informative denominator; keep ties and first observations as separate flags.
- Show original amount, absolute change and relative change together; flag small bases; any exclusion from a range needs an explicit reason and a separate transparent summary.
- A rule's existence in a document is not evidence of enforcement; code what the instructions required in that year.
- When many units change the same way in the same period, check for a single event at a higher-level unit (a merger, a renaming, a person moving, one organization recorded under two identities) before reading the change as many separate decisions. Report the series with and without such grouped movements, and treat the grouped movement as a substantive organizational event, not only as noise to remove. A cheap public check of the largest cases can change the reading of hundreds of records.
- In relationship data, a tie that is no longer recorded can mean different things. Keep the cases separate: the tie ended while both parties are still observed; one party is no longer observed; both are no longer observed; follow-up is incomplete. Only the first is a change of partner.
- Classify the condition an actor faced from what was documented at the time, not from what happened later. A rule that was later overturned or withdrawn was not thereby uncertain beforehand; keep later events in a separate retrospective field, and report contemporaneous uncertainty as unavailable where no evidence of it exists.
- A recorded characteristic that makes a rule relevant to a unit is not verified legal applicability, and a combination of such characteristics is not a set of simultaneous or conflicting demands. Keep relevance, applicability and geography as separate fields.
- Before computing network measures, write down each network's nodes, edges, direction, weights and treatment of disconnected parts. Keep networks built from different relations separate, report each named measure as itself and never substitute one under another's name, and flag patterns a projection creates by construction (one actor with three partners makes a closed triangle among them that is not three independent relationships).
- Who an entity is and who holds an interest are separate questions. An apparent hand-off in the records can be the same legal entity under a new identifier, an interest moved within a corporate group, or an interest sold to an independent organization. Only the first is an identity correction; the others are ownership changes. Keep four observations apart: an identifier changes; a legal owner changes; a corporate group changes; the underlying activity changes. Date every identifier and parent, do not assign earlier assets to a later parent, rebuild merged totals from the underlying records and never by adding totals, and never decide that two identifiers are one entity because merging them gives a more plausible result.
- An unmatched record is not necessarily a defect. Class it as an identity defect, a legitimate difference in what two sources cover, or an unresolved join.
- Check the intended cardinality before rejecting a join. Several components per unit, owners per asset or requirements per owner can be valid one-to-many relations: keep the relation table, aggregate to the analysis grain by a stated rule, and never multiply a measured quantity by the number of relation rows. That is different from conflicting candidate identities or an accidental cross product. A normalized key is not a new unit; report uniqueness, matches and totals before and after.
- When several actors share one object, separate what each actor did with its stake from what happened to the object. A jointly held asset has one operating history, and that history is not each holder's separate choice. Attach nothing the object did after an actor left to that actor. Leaving an activity and the activity ending are different outcomes.