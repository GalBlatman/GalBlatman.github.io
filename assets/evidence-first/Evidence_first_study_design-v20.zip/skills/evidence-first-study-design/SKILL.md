---
name: "evidence-first-study-design"
description: "Designs and steers an archival or document-based empirical research study in which a collection agent gathers the records: frames the research question, plans what evidence would answer it, checks feasibility, reads literature for design decisions, and keeps a multi-run project on its question. Use first for any work on such a study, including when it is unclear which part applies; it routes to evidence-first-run-and-audit (registrations, agent prompts, audits, data repairs) and evidence-first-read-and-decide (reading results, next steps, hypotheses). Not for manuscript prose, general statistics questions or software testing."
---

# Evidence-first study design

A way of working for empirical research where a question is tested against documents and records, part of the collection is done by an agent, and the findings must survive a critical reader. It is strict about evidence and flexible about design: it prevents invented facts, stale inputs, hidden changes and conclusions the records do not support; it does not prescribe a linear process, protect ideas from relevant literature, or turn one project's choices into rules for every study.

Develop the contribution and the empirical comparison together. A familiar explanation can leave important questions unresolved. A study can contribute by distinguishing arrangements previously treated alike, testing an unresolved implication, clarifying a relationship's limits, or improving its explanation. It need not establish every link in a larger theory. Establishing a phenomenon, estimating an effect, supporting an explanation and identifying a mechanism are different jobs, not steps on one ladder. Give each analysis a defined job, and distinguish what the evidence establishes from what remains an interpretation.

These are nine jobs, not nine one-way stages, kept in three skills so that only the part in use is loaded. The question, the literature and the design develop together; revisit each when reading or evidence changes what is understood. Register a specified test before examining the results it will use, and keep exploratory work clearly separate from tests of predictions written beforehand. For work already explored, record what has been seen and what remains unexamined rather than pretending no reading occurred.

No em dashes in anything produced under this skill.

## How the three skills fit

This is the core of three skills. It holds what applies on every use: the roles, how the project is steered across runs, and the design jobs (1, 2 and 4). Each companion works on its own for its jobs. Load one by name when its situation comes up, and only then.

| Situation | Skill |
|---|---|
| Framing the question, planning the evidence, checking feasibility, reading the literature, steering the project (Jobs 1, 2 and 4) | This skill |
| Registering a test, writing or reviewing an agent prompt, auditing a run, tracing a data correction, keeping the record (Jobs 3, 5, 6 and 7) | `evidence-first-run-and-audit` |
| Building measures, matching entities, handling identifiers, joins, shares or shared assets | The construction lessons in `evidence-first-run-and-audit` |
| Reading a result, comparing two readings, deciding what to do next, deciding which findings become hypotheses (Jobs 8 and 9) | `evidence-first-read-and-decide` |
| Building or checking a comparison (exposure, benchmarks, bins, choice sets, case selection, timing rules) | The comparison lessons in `evidence-first-read-and-decide` |

Answer what was asked. A narrow conceptual question gets a direct answer, not a new protocol, and a companion is loaded only when the task reaches its jobs.

**Keeping the three from growing.** Each rule has one home, in the skill whose job uses it; the other two point to it and do not restate it. A new lesson goes into the lessons list of the companion it belongs to, filed with when it applies. It moves into this core only if it applies on every use. Where two lessons overlap, merge them.

## Roles

- **Researcher**: owns the question, sets evidence requirements, adjudicates stops, supplies files the agent cannot reach.
- **Designer and auditor**: writes the question frame, the registered rules and the collection prompt; audits each checkpoint against them. Auditing execution and redesigning the study are separate acts; the rule is stated with the audit (Job 6, in `evidence-first-run-and-audit`).
- **Collector** (a coding agent): applies the agreed definitions to the documents, records the evidence behind judgment calls, flags unexpected patterns without explaining them, stops and reports at checkpoints. It does not infer motives, alter the design, or decide what findings mean theoretically. Reasons an organization states for itself are recorded as attributed statements, not accepted as proof of motive. The collector is not given the working explanation.
- **Second reader** (optional, a separate model or person): reads the same output independently, before seeing the first reading. Independent parallel reading catches errors in both directions and keeps one reader's framing from becoming the project's. How two readings are compared and reconciled is in `evidence-first-read-and-decide`.

Holding the question is the designer's job, not the researcher's. The researcher should not have to pull the work back to the question every few exchanges. The designer keeps the question, its explanatory side and its outcome side in the researcher's own words at the top of every prompt and every reading, and checks each new step against them before proposing it. A correction the researcher has to repeat calls for a changed next action, not another acknowledgement.

## Managing the project across runs

The tools get freedom to explore and interpret. They get very little freedom to redefine the question, narrow the evidence or declare an avenue closed. Routine, reversible implementation choices are made and reported; a choice that changes the scope, the evidence requirement or the status of an avenue goes to the researcher first.

- **Three levels.** The core question is fixed and carries one exit condition written in advance: the observation that would show the core is wrong. Leaving on that condition is a decision; leaving any other way is drift. The mechanism is revisable, one link at a time. Specifics (a measure, a sample, a window) are disposable. "Not X, but maybe Y" is allowed only when Y still answers the core question.
- **Three kinds of run, one standard each.** Label every agent run, so that its audit knows which standard applies. Explore: look broadly and report surprises; it must not reject a lead for failing confirmatory standards. Build: construct measures and report coverage, including the descriptive tables that show what was built; it must not treat missing data as invalidating an idea. Test: run one registered comparison faithfully; it must not change the hypothesis or rescue a failed prediction. The label fixes the standard a run is held to, not an order of work. What each kind of prompt carries (sealed plans and checkpoints for tests, containment for the rest) is in `evidence-first-run-and-audit`.
- **Laps, not a ladder.** Give every part of the proposed explanation a thin look before any part gets a thick one. Then list the combinations of parts the explanation depends on and check which of those have been looked at. A lap over the parts is not yet a look at the mechanism.
- **Say what each outcome would mean before the run,** for the designer's use, whenever the run makes a specified comparison. An open descriptive pass needs a stated learning question, not a conclusion for every possible result. Keep the working explanation out of the collector's prompt; what the prompt does carry is in `evidence-first-run-and-audit`.
- **One account page.** Keep a single short page that a restarted session reads first: the core and its exit condition, the mechanism as it stands, what was dropped and why, how the work is run, a parking lot for side findings, and the next step with its pre-stated readings. Update it after every run. Side findings go to the parking lot and are not pursued. If the project already has such a page, use it; do not start a second.
- **Repairs do not become the agenda.** Before a repair starts, name the finding or comparison it is meant to restore. Sweep for the defect once, trace what it changes, then return to that finding and to the question. The tracing steps are in `evidence-first-run-and-audit`.
- **Small questions stay small.** A re-cut the designer can do from a supplied file does not become an agent run. A classification made from general knowledge is labelled as such and checked against the records before anything rests on it.

## Job 1. Frame the question

Write one paragraph that answers, in order:

1. The question, stated without the preferred answer. If removing the favoured explanation leaves nothing worth asking, it is an argument, not a question.
2. What a reader would understand differently if it were answered. Say what the nearest research establishes, what it proposes, and what is open. A new setting or a new label is not a contribution by itself.
3. The level the explanation operates at (institution, organization, document, person) and whether the planned comparison observes that level or a proxy one level down.
4. What is known, what is inferred, and what is assumed, kept apart. A missing label is an observation; difficulty interpreting it is a further claim; doing it on purpose is an explanation.
5. The strongest existing expectation: what the records would look like under the leading account, and what remains worth learning even if that expectation holds.

Three frames to apply while writing. Zuckerman: what misunderstanding would the result correct, and who actually holds it. Stinchcombe: what would an explanation have to explain, with actors, activities, conditions and consequences; a name for a pattern is not an explanation. Langley: organize the real sequences before reducing anything to a coefficient.

## Job 2. Decide what evidence would answer it

Produce an expectations table, a list of comparisons, and a comparison feasibility statement (below).

- Give each plausible explanation its strongest form, including the ordinary one (routine, convention, document purpose, rule-following). Write what each expects to see across units, channels and time. Expectations can differ in timing, persistence, location or scope, not only in sign.
- Build comparisons that each do one job (establish the pattern, narrow the explanations, separate a change in behaviour from a change in the object). Several weak versions of one comparison do not become a strong one.
- Choose unit, population and period from the question, not from the workbook in hand. Repeated observations are used for what they hold constant, not for the row count.
- Write the conclusion for each possible result (as hoped, contrary, mixed, inconclusive) before building. If every result leaves the central uncertainty untouched, redesign.
- Say what each theoretical term means in the records, why the observed fact is informative about it, what else could produce it, and what it cannot establish. Participation is not dependence; a field's presence is not enforcement; a later-year record is not a contemporaneous one.

Locate the variation before fixing the sample:

- Identify the source and level of variation the explanation requires: what actually varies, at what level, and how many independent units carry that variation. Enumerate the relevant institutional, organizational or event-level contrasts before selecting a convenience population. If the theoretical variable is the type of regulatory obligation, the first population to inventory is the obligations and the units exposed to each, not the units with the cleanest records.
- Report how many independent units support each side of the contrast, including their overlap, clustering and temporal eligibility. A large number of repeated observations does not substitute for independent variation at the level of the claim.
- Find the source of the distinguishing attribute. For every theoretical contrast, name the source that establishes each side of the distinction. Do not assume that a dataset recording an activity or a quantity also records its legal status, governance, meaning, control or eligibility. Verify both sides affirmatively: an observed attribute versus an unknown attribute is not an established contrast. A measure of the quantity without a valid measure of the attribute that makes the quantity theoretically interesting does not support the comparison.
- Before writing hypotheses about two mechanisms, check that their measures are distinct organizational processes and not nested by construction (one indicator implying a positive value of the other). Two correlated regressors in one model do not identify two mechanisms; the real contrast is the one the nesting leaves open, and the units carrying it are counted before anything is claimed about it. A claim that one condition changes how another works is a conditional claim: two separate main effects do not test it, and a statistical interaction alone does not establish the process behind it.

Comparison feasibility statement. Before any major collection, write a short statement (a few lines, not a form or a deliverable) answering: what varies; where it varies; which source establishes it; what the independent unit is, including units that share a parent, a common source or the same exposure; what comparison is required; how many eligible units exist, counted before the final roster is chosen and labelled verified, estimated or upper bound; which source establishes the response; and what could prevent identification (for example, too few independent units with both sides of the contrast). The statement is the minimum needed to decide whether the study is worth pursuing. For a purely descriptive or qualitative project the same questions apply, with evidence requirements suited to that kind of claim. Do not write universal numerical thresholds into this step; any floor belongs to the individual design and is justified by its inferential goal.

Discovery and theory development:

- Before narrowing discovery to a mechanism-specific comparison, establish the empirical structure relevant to the question: dated sequences, contrasts, parallels, between-unit differences, within-unit changes and common calendar movements. Reuse existing descriptions where sufficient. Theory guides which distinctions matter; descriptive variation alone does not establish a theoretical anomaly. An anomaly is relative to an account: look for cases the strongest current account says should look alike but differ, or should differ but look alike.
- Give every proposed comparison a distinct learning purpose. Add a specification only when it establishes a distinct descriptive feature, addresses a named measurement problem, or distinguishes explanations. State what it adds beyond the comparisons already planned. Do not generate a combinatorial grid merely because several windows, transformations, populations and outcomes are available. Reporting every attempted specification is transparency, not a justification for generating overlapping ones. This limits what the designer adds. A broad pass the researcher asks for (a correlation matrix, a components analysis) is run as asked, with its purpose and units stated; its components are descriptions, not mechanisms.
- When a transformation changes the object being compared, reassess the inference. Document changes in units, denominators, ties, eligible observations and the estimand. For example, centering a binary outcome by year can turn previously equal observations into unequal ones. A sign reversal across different statistics is not automatically evidence that one corrected the other.
- The decision after a bounded diagnostic pass (Job 8) and the choice of which findings become hypotheses (Job 9) are in `evidence-first-read-and-decide`.

Then fit the design to the records:

- Consult the project's own records about these specific units before predicting fit, and state what changes because of what was found. The relevant knowledge must match the actual unit, object, period and source.
- Separate five questions: does the source exist, can it be obtained, does it contain the object (field by field, for every field the design matches on), does it cover the period, does its content support the comparison.
- Put access in the design. Manual retrieval and licence inquiries are planned stages with a time budget, not rescues. Foreseeable retrieval problems are not interruptions, and successful retrieval is not proof that the needed evidence is present.
- When the ideal observation is unavailable, ask what other arrangement of the evidence preserves the distinction, and state what changes in the inference. A neighbouring-year record can establish ordering even when it cannot serve as a same-period pair; a verified ordering can be usable where an exact date is not. Redesigning is legitimate; silently substituting a different observation while retaining the original claim is not. Do not default to "unmeasurable" or to "close enough".
- Distinguish an unavailable comparison from evidence against a prediction. Missing records may stop a design; an absent event may undermine a premise or become a finding worth explaining. Neither automatically closes the broader question.
- Verify every premise about the setting from a primary document (the standard's text, the form's own question wording, the rule's own instructions) before building on it. Nothing from memory.
- For an event-based comparison, verify what the event changes for the focal unit, when it changes, and whether the unit or relationship is still exposed then. An announcement, effective date, enforcement action, loss of eligibility, and interruption of a relationship are not interchangeable. Record an interval when the exact date is unknown. Align groups on calendar time, elapsed follow-up, and the pre-event conditions that make a response possible; explain any differences that remain.

Read the chain once more at the end: question, explanation, expected observation, comparison, available records, warranted conclusion. Mark where the meaning changed. The strongest objection should change the design where necessary, not appear only in a limitations paragraph.

## Job 4. Read the literature as a decision tool

- Before reading, state what uncertainty the paper may help resolve and, where it bears on a live link, what would change your mind. Read argument and empirical execution together. Afterwards record what it establishes, what it leaves open, and what changes in the question, explanation or design. Let a paper introduce distinctions absent from the existing framework; not every useful reading behaves like a registered test.
- Order reading by what it can teach: papers that can change a live idea early, but reading to understand an unfamiliar arrangement is valuable before its effect on any idea is known.
- Assess prior work by its claim, evidence, quality and relevance. Distinguish an explanation already proposed, a relationship already tested, and a phenomenon already documented. Venue and field inform the audience and positioning, not whether an argument or finding already exists. Engage relevant work wherever it appears. A prior paper can remove a novelty claim without settling the broader question. State what it has established and what the attainable study would still add.
- Adjacent literatures and technical sources are judged by what they support. A standard or legal text describing a rule does not establish an organizational mechanism; an adjacent literature may supply an explanation or expose a mistaken assumption. Engage adjacent research constructively: state what is borrowed, what it already explains, and what the study adds, and describe the relationship as an extension, qualification, challenge or application according to the substance, not a standing preference.
- For each paper, record the failure link: does it predict something this project already tested and closed, read at the scope that closure actually had.
- Harvest tools: measures, designs, identity tests, denominators. Attribute a measure to the source actually read: a theoretical citation or a later adaptation is not the original operationalization. Record its scope, units, period, denominator and edition.
- Record access level for every source: read directly, full text fetched, abstract or secondary, not found.
- When asked to work from a supplied source, stay within it and mark anything added from outside.

## Writing

Plain language, low cognitive load. Bottom line first. State denominators with every count. Report what holds, what is untested and what is methodological as three separate things. Do not overclaim: a scope condition is a scope condition. The jobs are a way of working, not an output template; do not print them back as a checklist. In a manuscript, lead with the theoretical question and the critical prediction; theoretical importance, not coefficient strength, orders the argument (Job 9, in `evidence-first-read-and-decide`).

The habit under all nine jobs: keep the question, the explanation and the design separate enough to revise each, and connected enough that revising one changes how you think about the others.